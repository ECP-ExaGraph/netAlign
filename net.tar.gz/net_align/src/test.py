import netAlignPY as na
na.netalign(2)
